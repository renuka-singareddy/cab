package com.capgemini.recharge.pi;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.service.*;

/**
 * Servlet implementation class RechargeController
 */
@WebServlet("/RechargeController")
public class RechargeController extends HttpServlet {
	IRechargingInterface ie=new Details();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechargeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int rid=ie.generateRechargeId();
		System.out.println(rid);
		LocalDate d=LocalDate.now();
		
		request.setAttribute("id", rid);
		request.setAttribute("date", d);
		request.getRequestDispatcher("/RechargeFrom.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RechargeBean b=new RechargeBean();
		
		b.setRechargeId(Integer.parseInt(request.getParameter("id")));
		b.setName(request.getParameter("name"));
		b.setMobileno(Long.parseLong(request.getParameter("mobile")));
		b.setStatus(request.getParameter("status"));
		b.setPlanname(request.getParameter("plan"));
		b.setRedate(Date.valueOf(request.getParameter("date")));
		int amount=ie.isValidPlanName(request.getParameter("plan"));
		b.setAmount(amount);
		ie.addRechargeData(b);
		
		
	}

}
