package com.capgemini.reharge.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.sql.DataSource;




public class DBConnection {
	
	private static Properties properties= new Properties();
	private static Connection connection;

	public static Connection getConnection(){
		
		try {
			/*InputStream inputStream =new FileInputStream("resources/jdbc.properties");
			properties.load(inputStream);
			String url=properties.getProperty("dburl");
			String user=properties.getProperty("username");
			String password=properties.getProperty("password");
			inputStream.close();*/
			
			/*DriverManager.registerDriver(new oracle.jdbc.OracleDriver()); 
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1109", "training1109");
			*/
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			connection=ds.getConnection();
		} catch (Exception e) {
		
		}
		
return connection;
} 
}
