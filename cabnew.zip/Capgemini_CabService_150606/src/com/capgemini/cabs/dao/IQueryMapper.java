package com.capgemini.cabs.dao;

import java.sql.Statement;

public interface IQueryMapper {
	//Statement sqls=conn.createStatement();
	String tablecreation = "CREATE TABLE cab_request " +
            "(request_id NUMBER, " +
            " customer_name VARCHAR(20), " + 
            " phone_number NUMBER(10), " +" date_of_request DATE, "+" request_status VARCHAR2(10), "+ 
            " cab_number VARCHAR2(10), " + 
            " address_of_pickup VARCHAR2(200), "+" pincode NUMBER(6))"; 
	public static final String sequenceRequestId="select rec_seq.nextval from dual";
	public static final String createSequence="create sequence recharge_charge start with 1000 increment by 1 nocycle";
	//public static final String insertRequestDetails="insert into rechargeInfo values(?,?,?,SYSDATE,?,?,?,?)";
	public static final String  insertRequestDetails="insert into cab_request values(?,?,?,?,?,?,?,?)";
	public static final String  requestid="select seq_request_id.nextval from dual";
	//sqls.executeQuery(sql);

}
