package com.capgemini.cabs.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cabs.dao.CabRequestDao;
import com.capgemini.cabs.dao.ICabRequestDao;
import com.capgemini.cabs.exception.CabsException;



public class CabService implements ICabService{

	@Override
	public String validateName(String customerName) {
		String regx = "^[a-zA-Z ]{3,}$";
	    Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
	    Matcher matcher = pattern.matcher(customerName);
	    boolean match=matcher.find();
	    String result=String.valueOf(match);
	    if(customerName.length()>20){
	    	result="Length of name is too large";
	    }
	    else{
	    	result="true";
	    }
	    return result;
	}
	@Override
	public String validatePhone(String phoneNumber) {
		String regx = "^[0-9]{10}$";
		Pattern pattern = Pattern.compile(regx);
		String s=String.valueOf(phoneNumber);
		Matcher matcher = pattern.matcher(s);
		boolean result=matcher.find();
		String validPhone=String.valueOf(result);
		if(result==false){
			validPhone="The phone number should contain only digits and length should be 10";
		}
		else{
			validPhone="true";
		}
		return validPhone;
	}
	@Override
	public void createTable() throws ClassNotFoundException, IOException, SQLException,CabsException {
		ICabRequestDao icabRequestdao=new CabRequestDao();
		icabRequestdao.createTable();
		
	}
	@Override
	public String validatePin(long pinCode) {
		String cabNumber;
		if(pinCode==400096){
			cabNumber="MH VS 2325";
		}
		else if(pinCode==411026){
			cabNumber="MH VH 34567";
		}
		else if(pinCode==411013){
			cabNumber="MH AN 97886";
		}
		else if(pinCode==560066){
			cabNumber="MH AS 875";
		}
		else if(pinCode==382009){
			cabNumber="MH KN 9856";
		}
		else if(pinCode==700708){
			cabNumber="MH TF 8956";
		}
		else{
			cabNumber=null;
		}
		return cabNumber;
	}
	@Override
	public long createRequest(String customerName, long phone,
			String pickupAddress, long pinCode,String validatePin,String status) throws IOException, SQLException,CabsException {
		ICabRequestDao icabRequestdao=new CabRequestDao();
		long requestid=icabRequestdao.createRequest(customerName,phone,pickupAddress,pinCode,validatePin,status);
		return requestid;
	}
	@Override
	public String[] checkstatus(long requestid) throws CabsException{
		ICabRequestDao icabRequestdao=new CabRequestDao();
		String details[]=icabRequestdao.createstatus(requestid);
		
		return details;
	}

}
