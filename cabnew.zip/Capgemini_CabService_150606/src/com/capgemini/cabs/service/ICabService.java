package com.capgemini.cabs.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.cabs.exception.CabsException;

public interface ICabService {
	String validateName(String customerName);
	String validatePhone(String phoneNumber);
	void createTable() throws ClassNotFoundException, IOException, SQLException,CabsException;
	String validatePin(long pinCode);
	long createRequest(String customerName, long phone, String pickupAddress, long pinCode,String validatePin,String status) throws IOException, SQLException,CabsException;
	String[] checkstatus(long requestid) throws CabsException;
}
